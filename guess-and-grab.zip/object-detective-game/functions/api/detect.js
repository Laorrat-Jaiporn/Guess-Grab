
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Cache-Control": "no-store"
    }
  });
}

export async function onRequestGet() {
  return json({ ready: true });
}

export async function onRequestPost({ request, env }) {
  // Read the Cloudflare Pages secret
  const apiKey = env?.ROBOFLOW_API_KEY;

  const apiKeyType = typeof apiKey;
  const apiKeyLength =
    typeof apiKey === "string" ? apiKey.length : null;

  // Check whether the secret is available
  if (typeof apiKey !== "string" || apiKey.trim() === "") {
    return json({
      error: "ROBOFLOW_API_KEY is empty or unavailable",
      hasEnv: Boolean(env),
      hasProperty: Boolean(
        env &&
        Object.prototype.hasOwnProperty.call(
          env,
          "ROBOFLOW_API_KEY"
        )
      ),
      apiKeyType,
      apiKeyLength,
      envKeys: env ? Object.keys(env) : []
    }, 500);
  }

  try {
    // Read the image sent by the game
    const body = await request.json();
    const image = body?.image;

    if (typeof image !== "string" || image.trim() === "") {
      return json({
        error: "Missing image data."
      }, 400);
    }

    // Call the Roboflow Workflow
    const upstream = await fetch(
      "https://serverless.roboflow.com/0702-khwanthip-sroisiri/workflows/object-detective-yf9zg",
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          api_key: apiKey.trim(),
          inputs: {
            image: {
              type: "base64",
              value: image
            }
          }
        })
      }
    );

    const responseText = await upstream.text();

    let result;

    try {
      result = JSON.parse(responseText);
    } catch {
      result = {
        error: "Roboflow returned a non-JSON response.",
        details: responseText.slice(0, 500)
      };
    }

    // Return useful error details if Roboflow rejects the request
    if (!upstream.ok) {
      return json({
        error: "Roboflow inference failed.",
        upstreamStatus: upstream.status,
        details: result
      }, 502);
    }

    // Return detection results to the game
    return json(result, 200);

  } catch (error) {
    return json({
      error: "Inference request failed.",
      details: error instanceof Error
        ? error.message
        : String(error)
    }, 500);
  }
}
